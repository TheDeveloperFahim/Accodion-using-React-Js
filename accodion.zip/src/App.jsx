import { Accrodion } from "./components/Accrodion";

const App = () => {
  return <>
    <Accrodion/>
  </>;
};

export default App;
