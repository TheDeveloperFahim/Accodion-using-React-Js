export const questions = [
  {
    id: 1,
    questions: "What is the virtual DOM ?",
    answer:
      "A virtual DOM is a lightweight JavaScript representation of the DOM used in declarative web frameworks such as React.",
  },
  {
    id: 2,
    questions: "How do you create a React app?",
    answer:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore tempore rerum, unde voluptatum iure cupiditate!",
  },
  {
    id: 3,
    questions: "Waht is an event in React ?",
    answer:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore tempore rerum, unde voluptatum iure cupiditate!",
  },
  {
    id: 4,
    questions: "Waht are synihtic event in React ?",
    answer:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore tempore rerum, unde voluptatum iure cupiditate!",
  },
  {
    id: 5,
    questions: "Waht are the component in React ?",
    answer:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore tempore rerum, unde voluptatum iure cupiditate!",
  },
];
